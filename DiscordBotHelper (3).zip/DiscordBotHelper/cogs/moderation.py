import discord
from discord.ext import commands
import logging

logger = logging.getLogger('discord_bot')

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='очистить')
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, amount: int = 5):
        """Очистить указанное количество сообщений"""
        try:
            await ctx.channel.purge(limit=amount + 1)
            logger.info(f'{ctx.author} cleared {amount} messages in {ctx.channel}')
            await ctx.send(f'Удалено {amount} сообщений.', delete_after=5)
        except discord.Forbidden:
            await ctx.send("У бота нет прав для удаления сообщений!")
        except Exception as e:
            logger.error(f'Error in clear command: {e}')
            await ctx.send("Произошла ошибка при удалении сообщений.")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
