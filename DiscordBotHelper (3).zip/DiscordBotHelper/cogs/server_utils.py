import discord
from discord.ext import commands
import logging
from datetime import datetime
import json
import os

logger = logging.getLogger('discord_bot')

class ServerUtils(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.messages_file = 'user_messages.json'
        self.messages_count = self.load_messages()
        logger.info('ServerUtils cog initialized')

    def load_messages(self):
        """Загрузить статистику сообщений из файла"""
        if os.path.exists(self.messages_file):
            try:
                with open(self.messages_file, 'r', encoding='utf-8') as f:
                    return {int(k): v for k, v in json.load(f).items()}
            except Exception as e:
                logger.error(f'Error loading messages stats: {e}')
                return {}
        return {}

    def save_messages(self):
        """Сохранить статистику сообщений в файл"""
        try:
            data = {str(k): v for k, v in self.messages_count.items()}
            with open(self.messages_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
            logger.info('Messages stats saved successfully')
        except Exception as e:
            logger.error(f'Error saving messages stats: {e}')

    @commands.Cog.listener()
    async def on_message(self, message):
        """Подсчет сообщений пользователей"""
        if message.author.bot:
            return

        user_id = message.author.id
        self.messages_count[user_id] = self.messages_count.get(user_id, 0) + 1
        self.save_messages()

    @commands.command(name='профиль')
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def profile(self, ctx, member: discord.Member = None):
        """Показать информацию о профиле участника"""
        member = member or ctx.author

        roles = [role.name for role in member.roles[1:]]  # Исключаем @everyone
        joined_at = member.joined_at.strftime("%d.%m.%Y") if member.joined_at else "Неизвестно"
        created_at = member.created_at.strftime("%d.%m.%Y")
        messages_count = self.messages_count.get(member.id, 0)

        embed = discord.Embed(
            title=f"Профиль {member.display_name}",
            color=member.color
        )

        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Присоединился", value=joined_at, inline=True)
        embed.add_field(name="Аккаунт создан", value=created_at, inline=True)
        embed.add_field(name="Сообщений", value=messages_count, inline=True)

        if roles:
            embed.add_field(name=f"Роли ({len(roles)})", value=", ".join(roles), inline=False)

        embed.set_footer(text=f"Запрошено пользователем {ctx.author}")
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} requested profile for {member}')

    @commands.command(name='топ')
    @commands.cooldown(1, 30, commands.BucketType.guild)
    async def top_members(self, ctx):
        """Показать топ 10 самых активных участников по сообщениям"""
        # Получаем список участников с сортировкой по количеству сообщений
        sorted_members = sorted(
            [(user_id, count) for user_id, count in self.messages_count.items()],
            key=lambda x: x[1],
            reverse=True
        )[:10]

        # Подсчитываем общее количество сообщений
        total_messages = sum(count for _, count in self.messages_count.items())

        embed = discord.Embed(
            title=f"📊 Топ 10 самых активных участников {ctx.guild.name}",
            description="По количеству отправленных сообщений:",
            color=discord.Color.gold()
        )

        # Эмодзи для первых трех мест
        medals = {1: "🥇", 2: "🥈", 3: "🥉"}

        for i, (user_id, count) in enumerate(sorted_members, 1):
            member = ctx.guild.get_member(user_id)
            if member:
                # Добавляем медаль для первых трех мест, или цифру для остальных
                place = medals.get(i, f"{i}.")
                # Вычисляем процент от общего количества сообщений
                percentage = (count / total_messages) * 100 if total_messages > 0 else 0
                embed.add_field(
                    name=f"{place} Место",
                    value=f"{member.mention}\nСообщений: **{count}** ({percentage:.1f}%)",
                    inline=False
                )

        embed.set_footer(text=f"Всего сообщений на сервере: {total_messages}")
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} requested top members list')

    @commands.command(name='опрос')
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def poll(self, ctx, *, question):
        """Создать опрос"""
        embed = discord.Embed(
            title="📊 Опрос",
            description=question,
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"Создал: {ctx.author}")

        # Отправляем опрос и добавляем реакции
        poll_message = await ctx.send(embed=embed)
        await poll_message.add_reaction('👍')
        await poll_message.add_reaction('👎')
        await poll_message.add_reaction('🤔')

        logger.info(f'{ctx.author} created a poll: {question}')

async def setup(bot):
    await bot.add_cog(ServerUtils(bot))