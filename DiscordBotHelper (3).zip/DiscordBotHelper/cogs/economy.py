import discord
from discord.ext import commands
import logging
import json
import os
import random
import asyncio
from datetime import datetime, timedelta

logger = logging.getLogger('discord_bot')

class JoinFactionButton(discord.ui.View):
    def __init__(self, faction_role_id):
        super().__init__(timeout=None)  # Делаем кнопку постоянной
        self.faction_role_id = faction_role_id

    @discord.ui.button(
        label="Вступить",
        style=discord.ButtonStyle.green,
        custom_id="join_faction"
    )
    async def join_faction(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            # Получаем роль фракции
            faction_role = interaction.guild.get_role(self.faction_role_id)
            if not faction_role:
                await interaction.response.send_message(
                    "Ошибка: роль фракции не найдена!",
                    ephemeral=True
                )
                return

            # Проверяем, не состоит ли пользователь уже в этой фракции
            if faction_role in interaction.user.roles:
                await interaction.response.send_message(
                    "Вы уже состоите в этой фракции!",
                    ephemeral=True
                )
                return

            # Выдаем роль фракции
            await interaction.user.add_roles(faction_role)
            await interaction.response.send_message(
                f"Вы успешно вступили во фракцию {faction_role.name}!",
                ephemeral=True
            )
            logger.info(f'User {interaction.user} joined faction {faction_role.name}')

        except Exception as e:
            logger.error(f'Error joining faction: {e}')
            await interaction.response.send_message(
                "Произошла ошибка при вступлении во фракцию!",
                ephemeral=True
            )

class FactionModal(discord.ui.Modal):
    def __init__(self, cog, *args, **kwargs):
        super().__init__(title="Создание фракции", *args, **kwargs)
        self.cog = cog

        self.add_item(discord.ui.TextInput(
            label="Название фракции",
            placeholder="Введите название вашей фракции",
            min_length=3,
            max_length=32
        ))

        self.add_item(discord.ui.TextInput(
            label="Описание",
            placeholder="Опишите цели и идеологию вашей фракции",
            style=discord.TextStyle.paragraph,
            min_length=10,
            max_length=1000
        ))

        self.add_item(discord.ui.TextInput(
            label="Требования для вступления",
            placeholder="Укажите требования к новым участникам",
            style=discord.TextStyle.paragraph
        ))

    async def on_submit(self, interaction: discord.Interaction):
        # Получаем введенные данные
        faction_name = self.children[0].value
        faction_description = self.children[1].value
        faction_requirements = self.children[2].value

        # Создаем категорию и каналы для фракции
        try:
            # Создаем роль фракции
            faction_role = await interaction.guild.create_role(
                name=f"👑 {faction_name}",
                reason=f"Faction created by {interaction.user}"
            )

            # Создаем категорию
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                faction_role: discord.PermissionOverwrite(read_messages=True),
                interaction.user: discord.PermissionOverwrite(administrator=True)
            }

            category = await interaction.guild.create_category(
                f"『👑』{faction_name}",
                overwrites=overwrites
            )

            # Создаем базовые каналы
            await category.create_text_channel("『📢』обьявления")
            await category.create_text_channel("『💭』общение")
            await category.create_voice_channel("『🔊』Голосовой")

            # Выдаем роль создателю
            await interaction.user.add_roles(faction_role)

            # Отправляем уведомление в канал запросов
            requests_channel = discord.utils.get(interaction.guild.channels, name="запросы")
            if requests_channel:
                embed = discord.Embed(
                    title="🎉 Создана новая фракция!",
                    description=f"Пользователь {interaction.user.mention} создал новую фракцию",
                    color=discord.Color.gold()
                )
                embed.add_field(name="Название", value=faction_name, inline=False)
                embed.add_field(name="Описание", value=faction_description, inline=False)
                embed.add_field(name="Требования", value=faction_requirements, inline=False)

                await requests_channel.send(embed=embed)

            # Отправляем информацию в канал фракций
            factions_channel = discord.utils.get(interaction.guild.channels, name="фракции")
            if factions_channel:
                faction_embed = discord.Embed(
                    title=f"👑 Фракция: {faction_name}",
                    description=faction_description,
                    color=discord.Color.blue()
                )
                faction_embed.add_field(name="Лидер", value=interaction.user.mention, inline=False)
                faction_embed.add_field(name="Требования", value=faction_requirements, inline=False)

                # Создаем view с кнопкой для вступления
                join_view = JoinFactionButton(faction_role.id)
                await factions_channel.send(embed=faction_embed, view=join_view)

            await interaction.response.send_message(
                f"✅ Фракция {faction_name} успешно создана! Проверьте новую категорию на сервере.",
                ephemeral=True
            )

        except Exception as e:
            logger.error(f"Error creating faction: {e}")
            self.cog.add_coins(interaction.user.id, 100000)  # Возвращаем монеты
            await interaction.response.send_message(
                "Произошла ошибка при создании фракции. Монеты возвращены.",
                ephemeral=True
            )

class ShopView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=60)
        self.cog = cog

    @discord.ui.button(label="Участник 1 Класса - 35000", style=discord.ButtonStyle.primary, custom_id="role_1")
    async def role_1_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_role_purchase(interaction, "Участник 1 Класса")

    @discord.ui.button(label="Участник 2 Класса - 25000", style=discord.ButtonStyle.primary, custom_id="role_2")
    async def role_2_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_role_purchase(interaction, "Участник 2 Класса")

    @discord.ui.button(label="Участник 3 Класса - 15000", style=discord.ButtonStyle.primary, custom_id="role_3")
    async def role_3_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_role_purchase(interaction, "Участник 3 Класса")

    @discord.ui.button(label="Кастом роль - 10000", style=discord.ButtonStyle.secondary, custom_id="custom_role")
    async def custom_role_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        price = self.cog.role_prices["Кастом роль"]
        if self.cog.remove_coins(interaction.user.id, price):
            await interaction.response.send_message(
                "Напишите желаемое название для вашей кастомной роли:",
                ephemeral=True
            )

            try:
                name_message = await self.cog.bot.wait_for(
                    'message',
                    timeout=60.0,
                    check=lambda m: m.author == interaction.user and m.channel == interaction.channel
                )

                color_view = RoleColorView()
                await interaction.followup.send(
                    "Выберите цвет для вашей роли:",
                    view=color_view,
                    ephemeral=True
                )

                try:
                    await color_view.wait()  # Ждем выбора цвета
                    if color_view.color is None:  # Если время истекло
                        self.cog.add_coins(interaction.user.id, price)
                        await interaction.followup.send(
                            "Время выбора цвета истекло. Монеты возвращены.",
                            ephemeral=True
                        )
                        return

                    # Создаем роль с выбранным цветом
                    role = await interaction.guild.create_role(
                        name=name_message.content,
                        colour=color_view.color,
                        reason=f"Custom role purchased by {interaction.user}"
                    )
                    await interaction.user.add_roles(role)
                    await interaction.followup.send(
                        f"Роль {role.mention} успешно создана!",
                        ephemeral=True
                    )

                except Exception as e:
                    logger.error(f"Error creating custom role: {e}")
                    self.cog.add_coins(interaction.user.id, price)
                    await interaction.followup.send(
                        "Произошла ошибка при создании роли. Монеты возвращены.",
                        ephemeral=True
                    )

            except asyncio.TimeoutError:
                self.cog.add_coins(interaction.user.id, price)
                await interaction.followup.send(
                    "Время ожидания истекло. Монеты возвращены.",
                    ephemeral=True
                )
        else:
            await interaction.response.send_message(
                "У вас недостаточно монет для покупки этой роли!",
                ephemeral=True
            )

    @discord.ui.button(label="Голосовой канал - 30000", style=discord.ButtonStyle.success, custom_id="voice_channel")
    async def voice_channel_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        price = 30000
        if self.cog.remove_coins(interaction.user.id, price):
            await interaction.response.send_message(
                "Напишите желаемое название для вашего голосового канала:",
                ephemeral=True
            )

            try:
                name_message = await self.cog.bot.wait_for(
                    'message',
                    timeout=60.0,
                    check=lambda m: m.author == interaction.user and m.channel == interaction.channel
                )

                try:
                    # Находим категорию голосовых каналов
                    category = discord.utils.get(interaction.guild.categories, name="🔊・Голосовые каналы")
                    if not category:
                        category = await interaction.guild.create_category("🔊・Голосовые каналы")

                    # Создаем канал с полными правами для создателя
                    overwrites = {
                        interaction.guild.default_role: discord.PermissionOverwrite(
                            view_channel=True,
                            connect=True
                        ),
                        interaction.user: discord.PermissionOverwrite(
                            view_channel=True,
                            connect=True,
                            manage_channels=True,
                            move_members=True,
                            mute_members=True,
                            deafen_members=True,
                            manage_permissions=True
                        )
                    }

                    voice_channel = await category.create_voice_channel(
                        name=name_message.content,
                        overwrites=overwrites
                    )

                    await interaction.followup.send(
                        f"Голосовой канал {voice_channel.mention} успешно создан! Вы получили полные права на управление каналом.",
                        ephemeral=True
                    )

                except Exception as e:
                    logger.error(f"Error creating voice channel: {e}")
                    self.cog.add_coins(interaction.user.id, price)
                    await interaction.followup.send(
                        "Произошла ошибка при создании канала. Монеты возвращены.",
                        ephemeral=True
                    )

            except asyncio.TimeoutError:
                self.cog.add_coins(interaction.user.id, price)
                await interaction.followup.send(
                    "Время ожидания истекло. Монеты возвращены.",
                    ephemeral=True
                )
        else:
            await interaction.response.send_message(
                "У вас недостаточно монет для создания голосового канала!",
                ephemeral=True
            )

    @discord.ui.button(label="Создать фракцию - 100000", style=discord.ButtonStyle.danger, custom_id="create_faction")
    async def create_faction_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        price = 100000
        if self.cog.remove_coins(interaction.user.id, price):
            try:
                # Открываем модальное окно для создания фракции
                modal = FactionModal(self.cog)
                await interaction.response.send_modal(modal)
            except Exception as e:
                logger.error(f"Error opening faction modal: {e}")
                self.cog.add_coins(interaction.user.id, price)
                await interaction.followup.send(
                    "Произошла ошибка при открытии формы создания фракции. Монеты возвращены.",
                    ephemeral=True
                )
        else:
            await interaction.response.send_message(
                "У вас недостаточно монет для создания фракции!",
                ephemeral=True
            )

    async def handle_role_purchase(self, interaction: discord.Interaction, role_name: str):
        price = self.cog.role_prices[role_name]
        if self.cog.remove_coins(interaction.user.id, price):
            try:
                role = discord.utils.get(interaction.guild.roles, name=role_name)
                if role:
                    await interaction.user.add_roles(role)
                    await interaction.response.send_message(
                        f"Вы успешно приобрели роль {role.mention}!",
                        ephemeral=True
                    )
                else:
                    self.cog.add_coins(interaction.user.id, price)
                    await interaction.response.send_message(
                        "Ошибка: роль не найдена на сервере",
                        ephemeral=True
                    )
            except Exception as e:
                logger.error(f"Error purchasing role: {e}")
                self.cog.add_coins(interaction.user.id, price)
                await interaction.response.send_message(
                    "Произошла ошибка при выдаче роли. Монеты возвращены.",
                    ephemeral=True
                )
        else:
            await interaction.response.send_message(
                "У вас недостаточно монет для покупки этой роли!",
                ephemeral=True
            )

class RoleColorView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)
        self.color = None

    @discord.ui.button(label="Красный", style=discord.ButtonStyle.red, custom_id="role_1")
    async def red_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.color = discord.Color.red()
        await interaction.response.send_message("Роль создается...", ephemeral=True)
        self.stop()

    @discord.ui.button(label="Синий", style=discord.ButtonStyle.blurple, custom_id="role_2")
    async def blue_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.color = discord.Color.blue()
        await interaction.response.send_message("Роль создается...", ephemeral=True)
        self.stop()

    @discord.ui.button(label="Зеленый", style=discord.ButtonStyle.green, custom_id="role_3")
    async def green_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.color = discord.Color.green()
        await interaction.response.send_message("Роль создается...", ephemeral=True)
        self.stop()

    @discord.ui.button(label="Золотой", style=discord.ButtonStyle.gray, custom_id="role_4")
    async def gold_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.color = discord.Color.gold()
        await interaction.response.send_message("Роль создается...", ephemeral=True)
        self.stop()

    @discord.ui.button(label="Фиолетовый", style=discord.ButtonStyle.gray, custom_id="role_5")
    async def purple_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.color = discord.Color.purple()
        await interaction.response.send_message("Роль создается...", ephemeral=True)
        self.stop()


class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.coins_file = 'neon_coins.json'
        self.coins = self.load_coins()
        self.farming_cooldowns = {}

        # Настройки ролей и цен
        self.role_prices = {
            "Участник 1 Класса": 35000,
            "Участник 2 Класса": 25000,
            "Участник 3 Класса": 15000,
            "Кастом роль": 10000
        }

        # Настройки фарма для разных ролей
        self.farming_ranges = {
            "Участник 1 Класса": (20, 100),
            "Участник 2 Класса": (10, 45),
            "Участник 3 Класса": (5, 25),
            "default": (10, 45)  # Стандартный диапазон
        }

    def load_coins(self):
        """Загрузить данные о монетах из файла"""
        if os.path.exists(self.coins_file):
            try:
                with open(self.coins_file, 'r', encoding='utf-8') as f:
                    return {int(k): v for k, v in json.load(f).items()}
            except Exception as e:
                logger.error(f'Error loading coins: {e}')
                return {}
        return {}

    def save_coins(self):
        """Сохранить данные о монетах в файл"""
        try:
            data = {str(k): v for k, v in self.coins.items()}
            with open(self.coins_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
            logger.info('Coins saved successfully')
        except Exception as e:
            logger.error(f'Error saving coins: {e}')

    def get_user_coins(self, user_id: int) -> int:
        """Получить количество монет пользователя"""
        return self.coins.get(user_id, 0)

    def add_coins(self, user_id: int, amount: int):
        """Добавить монеты пользователю"""
        self.coins[user_id] = self.get_user_coins(user_id) + amount
        self.save_coins()

    def remove_coins(self, user_id: int, amount: int) -> bool:
        """Удалить монеты у пользователя"""
        current_coins = self.get_user_coins(user_id)
        if current_coins >= amount:
            self.coins[user_id] = current_coins - amount
            self.save_coins()
            return True
        return False

    def get_farming_range(self, member: discord.Member):
        """Получить диапазон фарма для пользователя на основе его ролей"""
        for role_name, farming_range in self.farming_ranges.items():
            if discord.utils.get(member.roles, name=role_name):
                return farming_range
        return self.farming_ranges["default"]

    @commands.Cog.listener()
    async def on_message(self, message):
        """Начисление монет за сообщения"""
        if message.author.bot:
            return

        self.add_coins(message.author.id, 1)

    @commands.command(name='баланс')
    async def balance(self, ctx, member: discord.Member = None):
        """Показать баланс пользователя"""
        member = member or ctx.author
        coins = self.get_user_coins(member.id)

        embed = discord.Embed(
            title="💰 Баланс",
            description=f"{member.mention} имеет **{coins}** NEON COIN",
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)

    @commands.command(name='выдать-монеты')
    @commands.has_permissions(administrator=True)
    async def give_coins(self, ctx, member: discord.Member, amount: int):
        """Выдать монеты участнику (Только для администраторов)"""
        if amount <= 0:
            await ctx.send("Количество монет должно быть положительным числом!")
            return

        self.add_coins(member.id, amount)

        embed = discord.Embed(
            title="💰 Выдача монет",
            description=f"Администратор {ctx.author.mention} выдал {member.mention} **{amount}** NEON COIN",
            color=discord.Color.green()
        )
        embed.add_field(
            name="Новый баланс",
            value=f"**{self.get_user_coins(member.id)}** NEON COIN"
        )

        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} gave {amount} coins to {member}')

    @commands.command(name='фарма')
    @commands.cooldown(1, 720, commands.BucketType.user)  # 12 минут кулдаун
    async def farm(self, ctx):
        """Фарм монет"""
        try:
            farming_range = self.get_farming_range(ctx.author)
            earned = random.randint(*farming_range)
            self.add_coins(ctx.author.id, earned)

            embed = discord.Embed(
                title="💰 Фарм монет",
                description=f"Вы заработали **{earned}** NEON COIN!",
                color=discord.Color.green()
            )
            embed.set_footer(text="Следующий фарм будет доступен через 12 минут")

            await ctx.send(embed=embed)
            logger.info(f'{ctx.author} farmed {earned} coins')
        except Exception as e:
            logger.error(f'Error in farm command: {e}')
            await ctx.send("Произошла ошибка при выполнении команды.")

    @farm.error
    async def farm_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            minutes = int(error.retry_after / 60)
            seconds = int(error.retry_after % 60)
            await ctx.send(f"⏰ Подождите **{minutes}м {seconds}с** перед следующим фармом!")

    @commands.command(name='магазин')
    async def shop(self, ctx):
        """Показать магазин"""
        embed = discord.Embed(
            title="🏪 Магазин",
            description="Выберите товар для покупки:",
            color=discord.Color.blue()
        )

        # Категория ролей
        embed.add_field(
            name="👑 РОЛИ",
            value="```\n"
                  "Участник 1 Класса - 35000\n"
                  "Бонус к фарму: 20-100 монет\n\n"
                  "Участник 2 Класса - 25000\n"
                  "Бонус к фарму: 10-45 монет\n\n"
                  "Участник 3 Класса - 15000\n"
                  "Бонус к фарму: 5-25 монет\n\n"
                  "Кастом роль - 10000\n"
                  "Своя роль с выбором цвета\n"
                  "```",
            inline=False
        )

        # Категория голосовых каналов
        embed.add_field(
            name="🔊 ГОЛОСОВЫЕ ЧАТЫ",
            value="```\n"
                  "Создание голосового канала - 30000\n"
                  "Личный канал с полным управлением\n"
                  "```",
            inline=False
        )

        # Категория фракций
        embed.add_field(
            name="👥 ФРАКЦИИ",
            value="```\n"
                  "Создать свою фракцию - 100000\n"
                  "Своя категория с каналами и ролью\n"
                  "```",
            inline=False
        )

        view = ShopView(self)
        await ctx.send(embed=embed, view=view, ephemeral=True)

    @commands.command(name='удалить-голосовой')
    @commands.has_permissions(administrator=True)
    async def delete_voice_channel(self, ctx, channel: discord.VoiceChannel):
        """Удалить купленный голосовой канал (Только для администраторов)"""
        try:
            # Проверяем, находится ли канал в категории голосовых каналов
            if not channel.category or channel.category.name != "🔊・Голосовые каналы":
                await ctx.send("Этот канал не является купленным голосовым каналом!")
                return

            # Запрашиваем подтверждение
            confirm_msg = await ctx.send(f"Вы уверены, что хотите удалить канал {channel.mention}? Напишите 'да' для подтверждения.")

            try:
                response = await self.bot.wait_for(
                    'message',
                    timeout=30.0,
                    check=lambda m: m.author == ctx.author and m.channel == ctx.channel
                )

                if response.content.lower() == 'да':
                    await channel.delete(reason=f"Deleted by administrator {ctx.author}")
                    await ctx.send(f"✅ Голосовой канал успешно удален.")
                    logger.info(f'Voice channel {channel.name} deleted by {ctx.author}')
                else:
                    await ctx.send("❌ Удаление отменено.")

            except asyncio.TimeoutError:
                await ctx.send("❌ Время ожидания истекло. Удаление отменено.")

        except discord.Forbidden:
            await ctx.send("У бота недостаточно прав для удаления этого канала!")
        except Exception as e:
            logger.error(f'Error deleting voice channel: {e}')
            await ctx.send("Произошла ошибка при удалении канала.")

    @commands.command(name='удалить-роль')
    @commands.has_permissions(administrator=True)
    async def delete_custom_role(self, ctx, role: discord.Role):
        """Удалить кастомную роль (Только для администраторов)"""
        try:
            # Запрашиваем подтверждение
            confirm_msg = await ctx.send(f"Вы уверены, что хотите удалить роль {role.mention}? Напишите 'да' для подтверждения.")

            try:
                response = await self.bot.wait_for(
                    'message',
                    timeout=30.0,
                    check=lambda m: m.author == ctx.author and m.channel == ctx.channel
                )

                if response.content.lower() == 'да':
                    await role.delete(reason=f"Deleted by administrator {ctx.author}")
                    await ctx.send(f"✅ Роль успешно удалена.")
                    logger.info(f'Role {role.name} deleted by {ctx.author}')
                else:
                    await ctx.send("❌ Удаление отменено.")

            except asyncio.TimeoutError:
                await ctx.send("❌ Время ожидания истекло. Удаление отменено.")

        except discord.Forbidden:
            await ctx.send("У бота недостаточно прав для удаления этой роли!")
        except Exception as e:
            logger.error(f'Error deleting role: {e}')
            await ctx.send("Произошла ошибка при удалении роли.")

    @commands.command(name='удалить-фракцию')
    @commands.has_permissions(administrator=True)
    async def delete_faction(self, ctx, category: discord.CategoryChannel):
        """Удалить фракцию (Только для администраторов)"""
        try:
            # Проверяем, является ли категория фракцией
            if not category.name.startswith("『👑』"):
                await ctx.send("Эта категория не является фракцией!")
                return

            # Запрашиваем подтверждение
            confirm_msg = await ctx.send(
                f"Вы уверены, что хотите удалить фракцию {category.name}? "
                "Это действие удалит все каналы фракции и роль фракции. "
                "Напишите 'да' для подтверждения."
            )

            try:
                response = await self.bot.wait_for(
                    'message',
                    timeout=30.0,
                    check=lambda m: m.author == ctx.author and m.channel == ctx.channel
                )

                if response.content.lower() == 'да':
                    # Находим и удаляем роль фракции
                    faction_role = discord.utils.get(
                        ctx.guild.roles,
                        name=f"👑 {category.name.replace('『👑』', '')}"
                    )
                    if faction_role:
                        await faction_role.delete(reason=f"Faction deleted by {ctx.author}")

                    # Удаляем все каналы в категории
                    for channel in category.channels:
                        await channel.delete(reason=f"Faction deleted by {ctx.author}")

                    # Удаляем саму категорию
                    await category.delete(reason=f"Faction deleted by {ctx.author}")

                    await ctx.send(f"✅ Фракция успешно удалена.")
                    logger.info(f'Faction {category.name} deleted by {ctx.author}')

                    # Отправляем уведомление в канал запросов
                    requests_channel = discord.utils.get(ctx.guild.channels, name="запросы")
                    if requests_channel:
                        embed = discord.Embed(
                            title="❌ Фракция удалена",
                            description=f"Администратор {ctx.author.mention} удалил фракцию {category.name}",
                            color=discord.Color.red()
                        )
                        await requests_channel.send(embed=embed)
                else:
                    await ctx.send("❌ Удаление отменено.")

            except asyncio.TimeoutError:
                await ctx.send("❌ Время ожидания истекло. Удаление отменено.")

        except discord.Forbidden:
            await ctx.send("У бота недостаточно прав для удаления фракции!")
        except Exception as e:
            logger.error(f'Error deleting faction: {e}')
            await ctx.send("Произошла ошибка при удалении фракции.")

async def setup(bot):
    await bot.add_cog(Economy(bot))