import discord
from discord.ext import commands
import logging
import json
import os
from datetime import datetime
import asyncio  # Добавляем импорт asyncio

logger = logging.getLogger('discord_bot')

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Устанавливаем timeout=None для persistent view

    @discord.ui.button(
        label="Создать тикет",
        style=discord.ButtonStyle.green,
        custom_id="persistent_ticket:create"  # Уникальный custom_id для persistent button
    )
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Обработка создания тикета"""
        try:
            # Проверяем, есть ли уже открытый тикет у пользователя
            for channel in interaction.guild.channels:
                if channel.name.startswith(f"ticket-{interaction.user.name.lower()}"):
                    await interaction.response.send_message(
                        "У вас уже есть открытый тикет!",
                        ephemeral=True
                    )
                    return

            # Находим категорию для тикетов или создаем новую
            category = discord.utils.get(interaction.guild.categories, name="『🎫』Тикеты")
            if not category:
                category = await interaction.guild.create_category("『🎫』Тикеты")

            # Находим роль тех поддержки
            support_role = discord.utils.get(interaction.guild.roles, name="ТЕХ ПОДДЕРЖКА")
            if not support_role:
                await interaction.response.send_message(
                    "Ошибка: роль 'ТЕХ ПОДДЕРЖКА' не найдена на сервере!",
                    ephemeral=True
                )
                return

            # Настраиваем права доступа для канала
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.guild.me: discord.PermissionOverwrite(read_messages=True),
                interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                support_role: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True)
            }

            # Создаем канал для тикета
            channel = await interaction.guild.create_text_channel(
                name=f"ticket-{interaction.user.name.lower()}",
                category=category,
                overwrites=overwrites,
                topic=f"Тикет создан пользователем {interaction.user}"
            )

            # Создаем кнопку закрытия тикета
            close_view = TicketCloseView()

            # Отправляем первое сообщение в тикет
            embed = discord.Embed(
                title="Тикет создан",
                description="Опишите вашу проблему или вопрос. Служба поддержки ответит вам в ближайшее время.",
                color=discord.Color.green()
            )
            embed.add_field(name="Автор", value=interaction.user.mention)
            embed.add_field(name="Создан", value=discord.utils.format_dt(datetime.now(), style='R'))

            await channel.send(
                content=f"{interaction.user.mention} {support_role.mention}",
                embed=embed,
                view=close_view
            )

            # Отправляем подтверждение пользователю
            await interaction.response.send_message(
                f"Ваш тикет создан: {channel.mention}",
                ephemeral=True
            )

            # Отправляем уведомление в канал администрации
            admin_channel = discord.utils.get(interaction.guild.channels, name="админ-чат")
            if admin_channel:
                admin_embed = discord.Embed(
                    title="🎫 Новый тикет",
                    description=f"Пользователь {interaction.user.mention} создал новый тикет",
                    color=discord.Color.blue()
                )
                admin_embed.add_field(name="Канал", value=channel.mention)
                admin_embed.add_field(name="Создан", value=discord.utils.format_dt(datetime.now(), style='R'))

                await admin_channel.send(
                    content=f"{support_role.mention}",
                    embed=admin_embed
                )

            logger.info(f'Ticket created by {interaction.user} (Channel: {channel.name})')

        except Exception as e:
            logger.error(f'Error creating ticket: {e}')
            await interaction.response.send_message(
                "Произошла ошибка при создании тикета!",
                ephemeral=True
            )

class TicketCloseView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # Устанавливаем timeout=None для persistent view

    @discord.ui.button(
        label="Закрыть тикет",
        style=discord.ButtonStyle.red,
        custom_id="persistent_ticket:close"  # Уникальный custom_id для persistent button
    )
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Обработка закрытия тикета"""
        if not interaction.channel.name.startswith("ticket-"):
            await interaction.response.send_message(
                "Эта команда работает только в каналах тикетов!",
                ephemeral=True
            )
            return

        # Проверяем права пользователя
        support_role = discord.utils.get(interaction.guild.roles, name="ТЕХ ПОДДЕРЖКА")
        if not support_role in interaction.user.roles and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "У вас нет прав для закрытия тикетов!",
                ephemeral=True
            )
            return

        try:
            # Отправляем сообщение о закрытии
            embed = discord.Embed(
                title="Тикет закрывается",
                description="Этот тикет был закрыт и будет удален через 5 секунд.",
                color=discord.Color.red()
            )
            embed.add_field(name="Закрыт", value=discord.utils.format_dt(datetime.now(), style='R'))
            embed.add_field(name="Модератор", value=interaction.user.mention)

            await interaction.response.send_message(embed=embed)

            # Ждем 5 секунд и удаляем канал
            await asyncio.sleep(5)
            await interaction.channel.delete()
            logger.info(f'Ticket closed by {interaction.user} (Channel: {interaction.channel.name})')

        except Exception as e:
            logger.error(f'Error closing ticket: {e}')
            await interaction.response.send_message(
                "Произошла ошибка при закрытии тикета!",
                ephemeral=True
            )

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        logger.info('Tickets cog initialized')

    @commands.command(name='тикеты')
    @commands.has_permissions(administrator=True)
    async def setup_tickets(self, ctx, *, message=None):
        """Создать панель тикетов (Только для администраторов)"""
        if not message:
            message = "Нажмите на кнопку ниже, чтобы создать тикет в поддержку."

        embed = discord.Embed(
            title="🎫 Служба поддержки",
            description=message,
            color=discord.Color.blue()
        )

        view = TicketView()
        await ctx.send(embed=embed, view=view)
        logger.info(f'Ticket panel created by {ctx.author}')

async def setup(bot):
    cog = Tickets(bot)
    await bot.add_cog(cog)
    # Добавляем persistent view при загрузке cog
    bot.add_view(TicketView())
    bot.add_view(TicketCloseView())