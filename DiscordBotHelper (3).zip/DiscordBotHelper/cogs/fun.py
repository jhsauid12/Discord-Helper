import discord
from discord.ext import commands
import random
import logging
import asyncio
import aiohttp

logger = logging.getLogger('discord_bot')

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.magic_ball_answers = [
            "Да!", "Нет.", "Возможно.", "Определенно да!", "Определенно нет!",
            "Весьма вероятно.", "Вряд ли.", "Спроси позже.", "Лучше не говорить.",
            "Будущее туманно.", "Знаки говорят да.", "Знаки говорят нет."
        ]
        self.quotes = [
            "Не откладывай на завтра то, что можно сделать сегодня.",
            "Дорогу осилит идущий.",
            "Век живи — век учись.",
            "Под лежачий камень вода не течёт.",
            "Тише едешь — дальше будешь.",
            "Семь раз отмерь, один раз отрежь.",
            "Не имей сто рублей, а имей сто друзей.",
            "Кто рано встаёт, тому Бог подаёт."
        ]
        # Обновленные рабочие ссылки на мемы
        self.meme_urls = [
            "https://i.imgur.com/rW2DgiJ.gif",  # Котик
            "https://i.imgur.com/RSk7PaX.jpg",  # Мем про программирование
            "https://i.imgur.com/xBQOX1M.jpg",  # Забавный мем
            "https://i.imgur.com/3ZKwI42.jpg",  # Еще один мем
            "https://i.imgur.com/9PzbtHe.jpg"   # И еще один
        ]

    @commands.command(name='шар8')
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def magic_8_ball(self, ctx, *, question: str):
        """Магический шар ответит на ваш вопрос"""
        answer = random.choice(self.magic_ball_answers)
        embed = discord.Embed(
            title="🎱 Магический шар",
            description=f"**Вопрос:** {question}\n**Ответ:** {answer}",
            color=discord.Color.purple()
        )
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} used magic 8 ball with question: {question}')

    @commands.command(name='выбор')
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def choose(self, ctx, *options):
        """Бот выберет один из предложенных вариантов"""
        if len(options) < 2:
            await ctx.send("Укажите минимум 2 варианта через пробел!")
            return

        choice = random.choice(options)
        embed = discord.Embed(
            title="🎲 Случайный выбор",
            description=f"Я выбираю: **{choice}**",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} used choose command with options: {options}')

    @commands.command(name='цитата')
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def quote(self, ctx):
        """Получить случайную мудрую цитату"""
        quote = random.choice(self.quotes)
        embed = discord.Embed(
            title="📜 Мудрость дня",
            description=quote,
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} requested a quote')

    @commands.command(name='мем')
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def meme(self, ctx):
        """Получить случайный мем"""
        try:
            meme_url = random.choice(self.meme_urls)

            embed = discord.Embed(
                title="😄 Случайный мем",
                color=discord.Color.orange()
            )
            embed.set_image(url=meme_url)

            # Отправляем сообщение с загрузкой
            loading_msg = await ctx.send("🔄 Загружаю мем...")

            try:
                # Проверяем доступность изображения
                async with aiohttp.ClientSession() as session:
                    async with session.get(meme_url) as response:
                        if response.status == 200:
                            await loading_msg.delete()  # Удаляем сообщение о загрузке
                            await ctx.send(embed=embed)
                            logger.info(f'{ctx.author} requested a meme, URL: {meme_url}')
                        else:
                            await loading_msg.edit(content="❌ Не удалось загрузить мем, попробуйте еще раз.")
                            logger.error(f'Failed to load meme, status: {response.status}')
            except Exception as e:
                await loading_msg.edit(content="❌ Ошибка при загрузке мема.")
                logger.error(f'Error loading meme: {e}')

        except Exception as e:
            await ctx.send("❌ Произошла ошибка при отправке мема.")
            logger.error(f'Error in meme command: {e}')

async def setup(bot):
    await bot.add_cog(Fun(bot))