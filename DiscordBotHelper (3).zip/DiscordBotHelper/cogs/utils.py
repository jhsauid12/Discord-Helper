import discord
from discord.ext import commands
import logging
import asyncio
from datetime import datetime
import pytz
import math

logger = logging.getLogger('discord_bot')

class Utils(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reminders = {}

    @commands.command(name='время')
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def time(self, ctx, *, city: str):
        """Показать текущее время в указанном городе"""
        try:
            # Словарь соответствия городов и временных зон
            timezone_map = {
                'москва': 'Europe/Moscow',
                'санкт-петербург': 'Europe/Moscow',
                'новосибирск': 'Asia/Novosibirsk',
                'екатеринбург': 'Asia/Yekaterinburg',
                'владивосток': 'Asia/Vladivostok'
            }

            city_lower = city.lower()
            if city_lower not in timezone_map:
                await ctx.send("Извините, но я не знаю временную зону этого города.")
                return

            tz = pytz.timezone(timezone_map[city_lower])
            current_time = datetime.now(tz)

            embed = discord.Embed(
                title=f"🕒 Время в городе {city.title()}",
                description=f"Текущее время: **{current_time.strftime('%H:%M')}**",
                color=discord.Color.blue()
            )
            await ctx.send(embed=embed)
            logger.info(f'{ctx.author} requested time for {city}')

        except Exception as e:
            logger.error(f'Error in time command: {e}')
            await ctx.send("Произошла ошибка при получении времени.")

    @commands.command(name='калькулятор')
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def calculator(self, ctx, *, expression: str):
        """Простой калькулятор"""
        try:
            # Заменяем русские символы на английские
            expression = expression.replace('х', '*').replace('х', '*')

            # Проверяем на наличие опасных выражений
            if any(x in expression for x in ['import', 'exec', 'eval', '__']):
                await ctx.send("Недопустимое выражение!")
                return

            # Вычисляем результат
            result = eval(expression, {"__builtins__": None}, {"math": math})

            embed = discord.Embed(
                title="🔢 Калькулятор",
                description=f"Выражение: **{expression}**\nРезультат: **{result}**",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
            logger.info(f'{ctx.author} used calculator with expression: {expression}')

        except Exception as e:
            await ctx.send("Ошибка в выражении. Используйте только числа и операторы +, -, *, /")
            logger.error(f'Calculator error: {e}')

    @commands.command(name='напомни')
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def remind(self, ctx, time: int, *, text: str):
        """Установить напоминание (время в минутах)"""
        if time < 1 or time > 1440:  # максимум 24 часа
            await ctx.send("Время должно быть от 1 до 1440 минут (24 часа)")
            return

        embed = discord.Embed(
            title="⏰ Напоминание установлено",
            description=f"Я напомню вам через {time} минут:\n{text}",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)

        # Создаем задачу для напоминания
        await asyncio.sleep(time * 60)
        reminder_embed = discord.Embed(
            title="⏰ Напоминание!",
            description=text,
            color=discord.Color.orange()
        )
        await ctx.author.send(embed=reminder_embed)
        logger.info(f'Sent reminder to {ctx.author}: {text}')

async def setup(bot):
    await bot.add_cog(Utils(bot))