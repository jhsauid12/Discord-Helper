import discord
from discord.ext import commands
import logging

logger = logging.getLogger('discord_bot')

class Information(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='привет')
    async def hello(self, ctx):
        """Приветствие от бота"""
        await ctx.send(f'Привет, {ctx.author.mention}! 👋')

    @commands.command(name='помощь')
    async def help(self, ctx):
        """Показать список команд"""
        # Проверяем, является ли пользователь администратором
        is_admin = ctx.author.guild_permissions.administrator

        embed = discord.Embed(
            title="Список команд",
            description="Доступные команды бота:",
            color=discord.Color.blue()
        )

        # Базовые команды
        embed.add_field(
            name="Основные команды",
            value="```\n"
                  "!привет - Поприветствовать бота\n"
                  "!помощь - Показать это сообщение\n"
                  "!инфо - Показать информацию о сервере\n"
                  "```",
            inline=False
        )

        # Команды модерации (показываем только если пользователь админ)
        if is_admin:
            embed.add_field(
                name="Команды модерации",
                value="```\n"
                      "!очистить [количество] - Удалить сообщения\n"
                      "!мут [@участник] [причина] - Замутить участника\n"
                      "!размут [@участник] - Размутить участника\n"
                      "!кик [@участник] [причина] - Выгнать участника\n"
                      "!бан [@участник] [причина] - Забанить участника\n"
                      "!роль [@участник] [@роль] - Выдать/забрать роль\n"
                      "```",
                inline=False
            )

        # Развлекательные команды
        embed.add_field(
            name="🎮 Игры и развлечения",
            value="```\n"
                  "!монетка - Подбросить монетку\n"
                  "!кости [число] - Бросить кости\n"
                  "!игра - Камень-ножницы-бумага\n"
                  "!шар8 [вопрос] - Магический шар\n"
                  "!выбор [вариант1] [вариант2] - Случайный выбор\n"
                  "!цитата - Случайная мудрость\n"
                  "!мем - Случайный мем\n"
                  "```",
            inline=False
        )

        # Музыкальные команды
        embed.add_field(
            name="🎵 Музыка",
            value="```\n"
                  "!play [название/url] - Найти и проиграть музыку\n"
                  "!stop - Остановить музыку\n"
                  "```",
            inline=False
        )

        # Информационные команды
        embed.add_field(
            name="📊 Информация и утилиты",
            value="```\n"
                  "!время [город] - Время в городе\n"
                  "!калькулятор [выражение] - Калькулятор\n"
                  "!напомни [минуты] [текст] - Напоминание\n"
                  "!профиль [@участник] - Информация о профиле\n"
                  "!топ - Топ участников сервера\n"
                  "!опрос [вопрос] - Создать опрос\n"
                  "```",
            inline=False
        )

        # Команды настройки (показываем только если пользователь админ)
        if is_admin:
            embed.add_field(
                name="⚙️ Настройка сервера",
                value="```\n"
                      "!роли-реакции - Создать сообщение для ролей\n"
                      "!добавить-роль-реакцию @роль 👍 - Добавить роль\n"
                      "!сообщение 'Заголовок' Текст - Создать сообщение\n"
                      "!отправить-сообщение #канал - Отправить сообщение\n"
                      "!кастом - Помощь по настройке сервера\n"
                      "```",
                inline=False
            )

            # Добавляем напоминание о команде !вс для администраторов
            embed.set_footer(text="Используйте !вс для просмотра специальных команд администратора")

        await ctx.send(embed=embed)

    @commands.command(name='инфо')
    async def server_info(self, ctx):
        """Показать информацию о сервере"""
        server = ctx.guild

        embed = discord.Embed(
            title=f"Информация о сервере {server.name}",
            color=discord.Color.green()
        )

        embed.add_field(
            name="Владелец",
            value=server.owner.mention,
            inline=True
        )
        embed.add_field(
            name="Создан",
            value=server.created_at.strftime("%d.%m.%Y"),
            inline=True
        )
        embed.add_field(
            name="Количество участников",
            value=server.member_count,
            inline=True
        )
        embed.add_field(
            name="Количество каналов",
            value=len(server.channels),
            inline=True
        )
        embed.add_field(
            name="Количество ролей",
            value=len(server.roles),
            inline=True
        )

        if server.icon:
            embed.set_thumbnail(url=server.icon.url)

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Information(bot))