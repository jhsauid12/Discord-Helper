import discord
from discord.ext import commands
import random
import logging
import asyncio

logger = logging.getLogger('discord_bot')

class Games(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.rps_options = ['камень', 'ножницы', 'бумага']
        logger.info('Games cog initialized')

    @commands.command(name='монетка')
    async def flip_coin(self, ctx):
        """Подбросить монетку"""
        result = random.choice(['Орёл', 'Решка'])
        embed = discord.Embed(
            title="🎲 Подбрасываем монетку...",
            description=f"Выпало: **{result}**!",
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} flipped a coin, got {result}')

    @commands.command(name='кости')
    async def roll_dice(self, ctx, number: int = 6):
        """Бросить кости (можно указать максимальное число)"""
        if number < 2:
            await ctx.send("Минимальное число для костей: 2")
            return

        result = random.randint(1, number)
        embed = discord.Embed(
            title="🎲 Бросаем кости...",
            description=f"Выпало число: **{result}**!",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} rolled dice (1-{number}), got {result}')

    @commands.command(name='игра')
    async def play_rps(self, ctx):
        """Сыграть в камень-ножницы-бумага"""
        embed = discord.Embed(
            title="✌️ Камень-Ножницы-Бумага",
            description="Выберите свой вариант:\n🪨 камень\n✂️ ножницы\n📄 бумага",
            color=discord.Color.purple()
        )
        message = await ctx.send(embed=embed)

        # Добавляем реакции
        await message.add_reaction('🪨')
        await message.add_reaction('✂️')
        await message.add_reaction('📄')

        def check(reaction, user):
            return user == ctx.author and str(reaction.emoji) in ['🪨', '✂️', '📄']

        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=30.0, check=check)

            # Преобразуем эмодзи в выбор
            player_choice = {
                '🪨': 'камень',
                '✂️': 'ножницы',
                '📄': 'бумага'
            }[str(reaction.emoji)]

            bot_choice = random.choice(self.rps_options)

            # Определяем победителя
            result = self.get_rps_winner(player_choice, bot_choice)

            # Отправляем результат
            result_embed = discord.Embed(
                title="✌️ Результат игры",
                description=f"Вы выбрали: **{player_choice}**\nБот выбрал: **{bot_choice}**\n\n{result}",
                color=discord.Color.green()
            )
            await message.edit(embed=result_embed)
            logger.info(f'{ctx.author} played RPS: {player_choice} vs {bot_choice}, result: {result}')

        except asyncio.TimeoutError:
            await message.edit(embed=discord.Embed(
                title="❌ Время вышло",
                description="Вы не сделали выбор вовремя!",
                color=discord.Color.red()
            ))

    def get_rps_winner(self, player_choice, bot_choice):
        if player_choice == bot_choice:
            return "🤝 Ничья!"

        winning_combinations = {
            'камень': 'ножницы',
            'ножницы': 'бумага',
            'бумага': 'камень'
        }

        if winning_combinations[player_choice] == bot_choice:
            return "🎉 Вы победили!"
        return "😢 Бот победил!"

    @commands.command(name='игры')
    async def games_help(self, ctx):
        """Показать список доступных игр"""
        embed = discord.Embed(
            title="🎮 Игровые команды",
            description="Список доступных игр:",
            color=discord.Color.blue()
        )

        embed.add_field(
            name="🎲 Игры",
            value="```\n"
                  "!монетка - Подбросить монетку\n"
                  "!кости [число] - Бросить кости\n"
                  "!игра - Сыграть в камень-ножницы-бумага\n"
                  "```",
            inline=False
        )

        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} requested games help')

async def setup(bot):
    await bot.add_cog(Games(bot))