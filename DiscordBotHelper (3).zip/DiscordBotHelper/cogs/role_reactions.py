import discord
from discord.ext import commands
import logging
import json
import os

logger = logging.getLogger('discord_bot')

class RoleReactions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reaction_roles_file = 'reaction_roles.json'
        # Словарь для хранения связей реакция-роль
        self.reaction_roles = self.load_reaction_roles()
        logger.info('RoleReactions cog initialized')

    def load_reaction_roles(self):
        """Загрузить данные о реакциях-ролях из файла"""
        if os.path.exists(self.reaction_roles_file):
            try:
                with open(self.reaction_roles_file, 'r', encoding='utf-8') as f:
                    # Загружаем данные и конвертируем ключи обратно в int
                    data = json.load(f)
                    return {int(k): v for k, v in data.items()}
            except Exception as e:
                logger.error(f'Error loading reaction roles: {e}')
                return {}
        return {}

    def save_reaction_roles(self):
        """Сохранить данные о реакциях-ролях в файл"""
        try:
            # Конвертируем ключи в строки для JSON
            data = {str(k): v for k, v in self.reaction_roles.items()}
            with open(self.reaction_roles_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4)
            logger.info('Reaction roles saved successfully')
        except Exception as e:
            logger.error(f'Error saving reaction roles: {e}')

    @commands.command(name='роли-реакции')
    @commands.has_permissions(manage_roles=True)
    async def setup_reaction_roles(self, ctx, *, message=None):
        """Создать сообщение для получения ролей через реакции"""
        if not message:
            message = "Нажмите на реакцию ниже, чтобы получить соответствующую роль:"

        embed = discord.Embed(
            title="Получение ролей",
            description=message,
            color=discord.Color.blue()
        )

        roles_msg = await ctx.send(embed=embed)
        logger.info(f'Created reaction roles message in {ctx.channel.name}')

        # Инициализируем пустой словарь для реакций этого сообщения
        if roles_msg.id not in self.reaction_roles:
            self.reaction_roles[roles_msg.id] = {}
            self.save_reaction_roles()

        await ctx.send("Теперь используйте команду !добавить-роль-реакцию @роль 👍, ответив на любое сообщение")

    @commands.command(name='добавить-роль-реакцию')
    @commands.has_permissions(manage_roles=True)
    async def add_role_reaction(self, ctx, role: discord.Role, emoji: str):
        """Привязать роль к реакции (ответьте на любое сообщение этой командой)"""
        if not ctx.message.reference:
            await ctx.send("Вы должны ответить на сообщение этой командой!")
            return

        try:
            # Получаем сообщение, на которое ответили
            referenced_message = await ctx.fetch_message(ctx.message.reference.message_id)
            message_id = referenced_message.id

            # Инициализируем словарь для сообщения, если его еще нет
            if message_id not in self.reaction_roles:
                self.reaction_roles[message_id] = {}

            # Добавляем реакцию к сообщению
            await referenced_message.add_reaction(emoji)

            # Сохраняем связь реакции и роли
            self.reaction_roles[message_id][emoji] = role.id
            self.save_reaction_roles()

            logger.info(f'Added role reaction: {emoji} -> {role.name} for message {message_id}')
            await ctx.send(f"Реакция {emoji} привязана к роли {role.mention}")

        except discord.NotFound:
            await ctx.send("Сообщение не найдено.")
        except discord.HTTPException:
            await ctx.send("Неверный эмодзи.")
        except Exception as e:
            logger.error(f'Error adding role reaction: {e}')
            await ctx.send("Произошла ошибка при добавлении реакции.")

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        """Выдача роли при добавлении реакции"""
        if payload.message_id in self.reaction_roles:
            emoji = str(payload.emoji)
            if emoji in self.reaction_roles[payload.message_id]:
                guild = self.bot.get_guild(payload.guild_id)
                role = guild.get_role(self.reaction_roles[payload.message_id][emoji])
                member = guild.get_member(payload.user_id)

                if member and role and not member.bot:
                    try:
                        await member.add_roles(role)
                        logger.info(f'Added role {role.name} to {member.name}')
                    except discord.Forbidden:
                        logger.error(f'Failed to add role {role.name} to {member.name}: Missing permissions')

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload):
        """Удаление роли при удалении реакции"""
        if payload.message_id in self.reaction_roles:
            emoji = str(payload.emoji)
            if emoji in self.reaction_roles[payload.message_id]:
                guild = self.bot.get_guild(payload.guild_id)
                role = guild.get_role(self.reaction_roles[payload.message_id][emoji])
                member = guild.get_member(payload.user_id)

                if member and role and not member.bot:
                    try:
                        await member.remove_roles(role)
                        logger.info(f'Removed role {role.name} from {member.name}')
                    except discord.Forbidden:
                        logger.error(f'Failed to remove role {role.name} from {member.name}: Missing permissions')

    @commands.command(name='удалить-роль-реакцию')
    @commands.has_permissions(manage_roles=True)
    async def remove_role_reaction(self, ctx, role: discord.Role):
        """Удалить роль-реакцию (ответьте на сообщение с реакциями)"""
        if not ctx.message.reference:
            await ctx.send("Вы должны ответить на сообщение с реакциями!")
            return

        try:
            message_id = ctx.message.reference.message_id
            if message_id not in self.reaction_roles:
                await ctx.send("На этом сообщении нет настроенных ролей-реакций!")
                return

            # Ищем и удаляем реакцию для указанной роли
            found = False
            for emoji, role_id in list(self.reaction_roles[message_id].items()):
                if role_id == role.id:
                    del self.reaction_roles[message_id][emoji]
                    found = True
                    # Удаляем реакцию с сообщения
                    message = await ctx.fetch_message(message_id)
                    await message.clear_reaction(emoji)

            if found:
                # Если для сообщения больше нет реакций, удаляем его из словаря
                if not self.reaction_roles[message_id]:
                    del self.reaction_roles[message_id]
                self.save_reaction_roles()
                await ctx.send(f"Роль-реакция для {role.mention} удалена.")
                logger.info(f'Removed role reaction for role {role.name}')
            else:
                await ctx.send(f"Роль {role.mention} не найдена в реакциях этого сообщения.")

        except Exception as e:
            logger.error(f'Error removing role reaction: {e}')
            await ctx.send("Произошла ошибка при удалении роли-реакции.")

    @commands.command(name='сообщение')
    @commands.has_permissions(manage_messages=True)
    async def setup_custom_message(self, ctx, title=None, *, content=None):
        """Создать кастомное сообщение для сервера
        Использование: !сообщение "Заголовок" Текст сообщения"""
        if not title or not content:
            await ctx.send("Укажите заголовок и текст сообщения. Например:\n!сообщение \"Важное объявление\" Всем привет!")
            return

        embed = discord.Embed(
            title=title,
            description=content,
            color=discord.Color.green()
        )

        message = await ctx.send(embed=embed)
        self.custom_messages[message.id] = {"title": title, "content": content}
        logger.info(f'Created custom message in {ctx.channel.name}')

        await ctx.send("Сообщение создано! Используйте !отправить-сообщение чтобы отправить его в другой канал.")

    @commands.command(name='отправить-сообщение')
    @commands.has_permissions(manage_messages=True)
    async def send_custom_message(self, ctx, channel: discord.TextChannel):
        """Отправить кастомное сообщение в указанный канал (ответьте на сообщение этой командой)"""
        if not ctx.message.reference:
            await ctx.send("Вы должны ответить на кастомное сообщение этой командой!")
            return

        try:
            referenced_message = await ctx.fetch_message(ctx.message.reference.message_id)
            message_id = referenced_message.id

            if message_id not in self.custom_messages:
                await ctx.send("Это сообщение не является кастомным. Создайте сообщение командой !сообщение")
                return

            message_data = self.custom_messages[message_id]
            embed = discord.Embed(
                title=message_data["title"],
                description=message_data["content"],
                color=discord.Color.green()
            )

            await channel.send(embed=embed)
            logger.info(f'Sent custom message to channel {channel.name}')
            await ctx.send(f"Сообщение отправлено в канал {channel.mention}")

        except discord.NotFound:
            await ctx.send("Сообщение не найдено.")
        except discord.Forbidden:
            await ctx.send("У бота нет прав для отправки сообщений в этот канал!")

    @commands.command(name='кастом')
    async def custom_help(self, ctx):
        """Показать список команд для кастомизации сервера"""
        embed = discord.Embed(
            title="Команды кастомизации сервера",
            description="Список всех команд для настройки сервера:",
            color=discord.Color.blue()
        )

        # Команды для ролей-реакций
        embed.add_field(
            name="📌 Роли-реакции",
            value="```\n"
                  "!роли-реакции [текст] - Создать сообщение для ролей\n"
                  "!добавить-роль-реакцию @роль 👍 - Привязать роль к реакции\n"
                  "!удалить-роль-реакцию @роль - Удалить роль-реакцию\n"
                  "(Ответьте этой командой на сообщение с ролями)\n"
                  "```",
            inline=False
        )

        # Команды для сообщений
        embed.add_field(
            name="💬 Кастомные сообщения",
            value="```\n"
                  '!сообщение "Заголовок" Текст - Создать сообщение\n'
                  "!отправить-сообщение #канал - Отправить сообщение\n"
                  "(Ответьте этой командой на кастомное сообщение)\n"
                  "```",
            inline=False
        )

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(RoleReactions(bot))