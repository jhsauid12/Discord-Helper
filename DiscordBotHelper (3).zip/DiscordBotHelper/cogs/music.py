import asyncio
import discord
from discord.ext import commands
import logging
import yt_dlp

logger = logging.getLogger('discord_bot')

# Настройки для yt-dlp
ytdl_format_options = {
    'format': 'bestaudio/best',
    'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'noplaylist': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'quiet': True,
    'no_warnings': True,
    'default_search': 'auto',
    'source_address': '0.0.0.0',
    'extract_flat': True,  # Для лучшей поддержки YouTube Music
    'extractor_args': {
        'youtube': {
            'skip': ['dash', 'hls'],  # Пропускаем некоторые форматы для ускорения
        },
    },
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }],
}

ffmpeg_options = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn -b:a 192k'  # Улучшенное качество аудио
}

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ytdl = yt_dlp.YoutubeDL(ytdl_format_options)
        logger.info('Музыкальный модуль инициализирован')

    async def ensure_voice_connection(self, ctx):
        """Проверяет и устанавливает голосовое подключение"""
        if not ctx.author.voice:
            raise ValueError("Вы должны находиться в голосовом канале!")

        channel = ctx.author.voice.channel
        logger.info(f'Попытка подключения к каналу: {channel.name}')

        if ctx.voice_client is None:
            vc = await channel.connect()
            logger.info('Успешно подключились к каналу')
        elif ctx.voice_client.channel != channel:
            await ctx.voice_client.move_to(channel)
            vc = ctx.voice_client
            logger.info('Перешли в другой канал')
        else:
            vc = ctx.voice_client
            logger.info('Уже подключены к нужному каналу')

        return vc

    async def get_track_info(self, query):
        """Получает информацию о треке"""
        logger.info(f'Получение информации о треке: {query}')

        if not query.startswith(('https://', 'http://')):
            logger.info('Поисковый запрос, добавляем ytsearch:')
            query = f"ytsearch:{query}"
        elif 'music.youtube.com' in query:
            logger.info('Конвертация ссылки YouTube Music в обычную YouTube ссылку')
            query = query.replace('music.youtube.com', 'www.youtube.com')

        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(None, lambda: self.ytdl.extract_info(query, download=False))

        if not data:
            logger.error('Не удалось получить данные о треке')
            raise ValueError("Не удалось найти трек")

        if 'entries' in data:
            logger.info('Получен список треков, берем первый')
            data = data['entries'][0]

        # Логируем полученные данные
        logger.info(f'Получены данные трека: title={data.get("title")}, duration={data.get("duration")}')
        logger.info(f'URL типа: {type(data.get("url"))}')

        return data

    @commands.command(name='play')
    async def play(self, ctx, *, query):
        """Проигрывает музыку из YouTube
        !play <название или ссылка>"""
        loading_msg = await ctx.send("🔄 Загружаю...")

        try:
            # Шаг 1: Подключение к голосовому каналу
            vc = await self.ensure_voice_connection(ctx)

            # Шаг 2: Получение информации о треке
            data = await self.get_track_info(query)

            # Шаг 3: Подготовка к воспроизведению
            if vc.is_playing():
                logger.info('Останавливаем текущее воспроизведение')
                vc.stop()

            # Шаг 4: Создание и запуск аудио
            logger.info('Создание аудио источника')
            audio = discord.FFmpegPCMAudio(data['url'], **ffmpeg_options)

            logger.info('Начало воспроизведения')
            vc.play(audio, after=lambda e: 
                asyncio.run_coroutine_threadsafe(
                    self.on_playback_finished(ctx, e), 
                    self.bot.loop
                )
            )

            # Шаг 5: Отображение информации
            embed = discord.Embed(
                title="🎵 Сейчас играет",
                description=f"**{data['title']}**",
                color=discord.Color.green()
            )

            if data.get('thumbnail'):
                embed.set_thumbnail(url=data['thumbnail'])

            if data.get('duration'):
                minutes = data['duration'] // 60
                seconds = data['duration'] % 60
                embed.add_field(name="Длительность", value=f"{minutes}:{seconds:02d}")

            await loading_msg.edit(content=None, embed=embed)
            logger.info(f'Успешно начато воспроизведение: {data["title"]}')

        except ValueError as e:
            logger.warning(f'Ошибка валидации: {str(e)}')
            await loading_msg.edit(content=f"❌ {str(e)}")
        except Exception as e:
            logger.error(f'Ошибка воспроизведения: {str(e)}')
            await loading_msg.edit(content=f"❌ Произошла ошибка: {str(e)}")
            if ctx.voice_client:
                await ctx.voice_client.disconnect()

    async def on_playback_finished(self, ctx, error):
        """Вызывается после окончания воспроизведения"""
        if error:
            logger.error(f'Ошибка воспроизведения: {error}')
            await ctx.send("❌ Произошла ошибка при воспроизведении.")

    @commands.command(name='stop')
    async def stop(self, ctx):
        """Останавливает воспроизведение и отключает бота от канала"""
        if not ctx.voice_client:
            return await ctx.send("Бот не находится в голосовом канале!")

        await ctx.voice_client.disconnect()
        await ctx.send("🛑 Музыка остановлена")
        logger.info(f'Бот отключен от голосового канала пользователем {ctx.author}')

async def setup(bot):
    await bot.add_cog(Music(bot))