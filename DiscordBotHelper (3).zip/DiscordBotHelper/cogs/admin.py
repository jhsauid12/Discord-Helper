import discord
from discord.ext import commands
import logging

logger = logging.getLogger('discord_bot')

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.admin_role = "Admin / Developer"  # Убрал @
        self.manager_role = "Community Manager"  # Убрал @
        self.moderator_role = "Moderator"  # Убрал @

    def has_required_role(self, member, role_name):
        logger.info(f"Checking role {role_name} for member {member.name}")
        logger.info(f"Member roles: {[role.name for role in member.roles]}")
        return discord.utils.get(member.roles, name=role_name) is not None

    @commands.command(name='кик')
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason=None):
        """Выгнать участника с сервера (Moderator+)"""
        logger.info(f"Kick command used by {ctx.author.name} with roles: {[role.name for role in ctx.author.roles]}")

        if not any(self.has_required_role(ctx.author, role) for role in [self.admin_role, self.manager_role, self.moderator_role]):
            logger.warning(f"Permission denied for {ctx.author.name} trying to use kick command")
            await ctx.send("У вас нет прав для использования этой команды!")
            return

        try:
            await member.kick(reason=reason)
            await ctx.send(f'{member.mention} был выгнан.\nПричина: {reason if reason else "не указана"}')
            logger.info(f'{ctx.author} kicked {member} for reason: {reason}')
        except discord.Forbidden:
            await ctx.send("У меня нет прав для выполнения этого действия!")

    @commands.command(name='бан')
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
        """Забанить участника (Admin / Manager only)"""
        logger.info(f"Ban command used by {ctx.author.name} with roles: {[role.name for role in ctx.author.roles]}")

        if not any(self.has_required_role(ctx.author, role) for role in [self.admin_role, self.manager_role]):
            logger.warning(f"Permission denied for {ctx.author.name} trying to use ban command")
            await ctx.send("Эта команда доступна только для Admin и Community Manager!")
            return

        try:
            await member.ban(reason=reason)
            await ctx.send(f'{member.mention} был забанен.\nПричина: {reason if reason else "не указана"}')
            logger.info(f'{ctx.author} banned {member} for reason: {reason}')
        except discord.Forbidden:
            await ctx.send("У меня нет прав для выполнения этого действия!")

    @commands.command(name='роль')
    @commands.has_permissions(manage_roles=True)
    async def role(self, ctx, member: discord.Member, *, role: discord.Role):
        """Выдать/забрать роль у участника (Manager+)"""
        logger.info(f"Role command used by {ctx.author.name} with roles: {[role.name for role in ctx.author.roles]}")

        if not any(self.has_required_role(ctx.author, role) for role in [self.admin_role, self.manager_role]):
            logger.warning(f"Permission denied for {ctx.author.name} trying to use role command")
            await ctx.send("Эта команда доступна только для Admin и Community Manager!")
            return

        try:
            if role in member.roles:
                await member.remove_roles(role)
                action = "убрана у"
            else:
                await member.add_roles(role)
                action = "выдана"
            await ctx.send(f'Роль {role.mention} была {action} {member.mention}')
            logger.info(f'{ctx.author} modified role {role.name} for {member}')
        except discord.Forbidden:
            await ctx.send("У меня нет прав для управления этой ролью!")

    @commands.command(name='мут')
    @commands.has_permissions(manage_messages=True)
    async def mute(self, ctx, member: discord.Member, *, reason=None):
        """Замутить участника (Moderator+)"""
        logger.info(f"Mute command used by {ctx.author.name} with roles: {[role.name for role in ctx.author.roles]}")

        if not any(self.has_required_role(ctx.author, role) for role in [self.admin_role, self.manager_role, self.moderator_role]):
            logger.warning(f"Permission denied for {ctx.author.name} trying to use mute command")
            await ctx.send("У вас нет прав для использования этой команды!")
            return

        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not muted_role:
            try:
                muted_role = await ctx.guild.create_role(name="Muted")
                for channel in ctx.guild.channels:
                    await channel.set_permissions(muted_role, speak=False, send_messages=False)
            except discord.Forbidden:
                await ctx.send("Не удалось создать роль Muted!")
                return

        try:
            await member.add_roles(muted_role)
            await ctx.send(f'{member.mention} был замучен.\nПричина: {reason if reason else "не указана"}')
            logger.info(f'{ctx.author} muted {member} for reason: {reason}')
        except discord.Forbidden:
            await ctx.send("У меня нет прав для выполнения этого действия!")

    @commands.command(name='размут')
    @commands.has_permissions(manage_messages=True)
    async def unmute(self, ctx, member: discord.Member):
        """Размутить участника (Moderator+)"""
        logger.info(f"Unmute command used by {ctx.author.name} with roles: {[role.name for role in ctx.author.roles]}")

        if not any(self.has_required_role(ctx.author, role) for role in [self.admin_role, self.manager_role, self.moderator_role]):
            logger.warning(f"Permission denied for {ctx.author.name} trying to use unmute command")
            await ctx.send("У вас нет прав для использования этой команды!")
            return

        muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if not muted_role:
            await ctx.send("Роль Muted не найдена!")
            return

        try:
            await member.remove_roles(muted_role)
            await ctx.send(f'{member.mention} был размучен.')
            logger.info(f'{ctx.author} unmuted {member}')
        except discord.Forbidden:
            await ctx.send("У меня нет прав для выполнения этого действия!")

async def setup(bot):
    await bot.add_cog(Admin(bot))