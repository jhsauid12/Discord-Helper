import discord
from discord.ext import commands
import json
import os
import logging

logger = logging.getLogger('discord_bot')

class Warnings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings_file = 'warnings.json'
        self.warnings = self.load_warnings()
        self.max_warnings = 3
        logger.info('Warnings cog initialized')

    def load_warnings(self):
        """Загрузить данные о выговорах из файла"""
        if os.path.exists(self.warnings_file):
            try:
                with open(self.warnings_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f'Error loading warnings: {e}')
                return {}
        return {}

    def save_warnings(self):
        """Сохранить данные о выговорах в файл"""
        try:
            with open(self.warnings_file, 'w', encoding='utf-8') as f:
                json.dump(self.warnings, f, indent=4)
            logger.info('Warnings saved successfully')
        except Exception as e:
            logger.error(f'Error saving warnings: {e}')

    @commands.command(name='выговор')
    @commands.has_permissions(administrator=True)
    async def warn(self, ctx, member: discord.Member, *, reason=None):
        """Выдать выговор участнику (Только для администраторов)"""
        user_id = str(member.id)
        
        current_warnings = self.warnings.get(user_id, 0)
        if current_warnings >= self.max_warnings:
            await ctx.send(f"{member.mention} уже имеет максимальное количество выговоров!")
            return

        self.warnings[user_id] = current_warnings + 1
        self.save_warnings()

        embed = discord.Embed(
            title="⚠️ Выговор",
            description=f"Участник {member.mention} получил выговор.",
            color=discord.Color.red()
        )
        embed.add_field(name="Причина", value=reason or "Не указана")
        embed.add_field(name="Всего выговоров", value=f"{self.warnings[user_id]}/{self.max_warnings}")
        
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} gave warning to {member} (reason: {reason})')

    @commands.command(name='снять-выговор')
    @commands.has_permissions(administrator=True)
    async def remove_warning(self, ctx, member: discord.Member):
        """Снять выговор с участника (Только для администраторов)"""
        user_id = str(member.id)
        
        if user_id not in self.warnings or self.warnings[user_id] == 0:
            await ctx.send(f"{member.mention} не имеет выговоров!")
            return

        self.warnings[user_id] -= 1
        if self.warnings[user_id] == 0:
            del self.warnings[user_id]
        self.save_warnings()

        embed = discord.Embed(
            title="✅ Снятие выговора",
            description=f"С участника {member.mention} снят выговор.",
            color=discord.Color.green()
        )
        embed.add_field(
            name="Осталось выговоров", 
            value=str(self.warnings.get(user_id, 0))
        )
        
        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} removed warning from {member}')

    @commands.command(name='выговоры')
    @commands.has_permissions(administrator=True)
    async def check_warnings(self, ctx, member: discord.Member = None):
        """Показать количество выговоров участника (Только для администраторов)"""
        if member is None:
            # Показываем список всех участников с выговорами
            if not self.warnings:
                await ctx.send("На сервере нет участников с выговорами!")
                return

            embed = discord.Embed(
                title="📊 Список выговоров",
                color=discord.Color.blue()
            )

            for user_id, count in self.warnings.items():
                user = ctx.guild.get_member(int(user_id))
                if user:
                    embed.add_field(
                        name=f"{user.display_name}",
                        value=f"Выговоров: {count}/{self.max_warnings}",
                        inline=False
                    )

            await ctx.send(embed=embed)
        else:
            # Показываем информацию о конкретном участнике
            user_id = str(member.id)
            count = self.warnings.get(user_id, 0)
            
            embed = discord.Embed(
                title="📊 Информация о выговорах",
                description=f"Участник: {member.mention}",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="Количество выговоров",
                value=f"{count}/{self.max_warnings}"
            )
            
            await ctx.send(embed=embed)
        
        logger.info(f'{ctx.author} checked warnings')

    @commands.command(name='вс')
    @commands.has_permissions(administrator=True)
    async def admin_help(self, ctx):
        """Показать список команд для администраторов"""
        embed = discord.Embed(
            title="🛡️ Команды администратора",
            description="Список специальных команд для управления сервером:",
            color=discord.Color.gold()
        )

        # Команды для выговоров
        embed.add_field(
            name="⚠️ Система выговоров",
            value="```\n"
                  "!выговор @участник [причина] - Выдать выговор\n"
                  "!снять-выговор @участник - Снять выговор\n"
                  "!выговоры [@участник] - Показать выговоры\n"
                  "```",
            inline=False
        )

        # Команды экономики
        embed.add_field(
            name="💰 Система экономики",
            value="```\n"
                  "!выдать-монеты @участник сумма - Выдать монеты\n"
                  "!удалить-голосовой #канал - Удалить голосовой канал\n"
                  "!удалить-роль @роль - Удалить кастомную роль\n"
                  "!удалить-фракцию категория - Удалить фракцию\n"
                  "```",
            inline=False
        )

        # Команды тикетов
        embed.add_field(
            name="🎫 Система тикетов",
            value="```\n"
                  "!тикеты [сообщение] - Создать панель тикетов\n"
                  "```",
            inline=False
        )

        await ctx.send(embed=embed)
        logger.info(f'{ctx.author} requested admin help')

async def setup(bot):
    await bot.add_cog(Warnings(bot))