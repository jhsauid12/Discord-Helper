import os
import discord
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv
from utils.logger import setup_logger
import logging

# Load environment variables
load_dotenv()

# Setup logging
logger = setup_logger()

# Bot configuration
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

class CustomBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix='!', intents=intents)
        self.processing_commands = set()
        self.command_spam_check = {}
        self.tree.on_error = self.on_app_command_error
        logger.info('Bot initialized with custom handlers')

    async def setup_hook(self):
        """This is called when the bot is starting up"""
        logger.info("Running setup hook...")
        for extension in initial_extensions:
            try:
                await self.load_extension(extension)
                logger.info(f'Loaded extension {extension}')
            except Exception as e:
                logger.error(f'Failed to load extension {extension}: {e}')

    async def on_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        """Обработчик ошибок для слэш-команд"""
        if isinstance(error, app_commands.CommandOnCooldown):
            await interaction.response.send_message(
                f"⏰ Подождите {error.retry_after:.1f} секунд перед повторным использованием команды.",
                ephemeral=True
            )
        elif isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                "У вас нет прав для выполнения этой команды!",
                ephemeral=True
            )
        else:
            logger.error(f'Slash command error occurred: {error}')
            await interaction.response.send_message(
                "Произошла ошибка при выполнении команды.",
                ephemeral=True
            )

    async def process_commands(self, message):
        if message.author.bot:
            return

        ctx = await self.get_context(message)
        if not ctx.valid or ctx.command is None:
            return

        # Создаем уникальный ключ для команды
        command_key = (ctx.command.name, message.id)

        # Проверяем, не обрабатывается ли уже эта команда
        if command_key in self.processing_commands:
            logger.debug(f'Duplicate command execution prevented: {ctx.command.name}')
            return

        try:
            self.processing_commands.add(command_key)
            await super().process_commands(message)
        finally:
            self.processing_commands.remove(command_key)

bot = CustomBot()

# Load cogs
initial_extensions = [
    'cogs.moderation',
    'cogs.information',
    'cogs.admin',
    'cogs.role_reactions',
    'cogs.games',
    'cogs.fun',
    'cogs.utils',
    'cogs.server_utils',
    'cogs.music',
    'cogs.warnings',
    'cogs.economy',
    'cogs.tickets'  # Добавляем новый cog
]

@bot.event
async def on_ready():
    logger.info(f'Bot is ready! Logged in as {bot.user.name}')
    # Синхронизируем слэш-команды
    try:
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} command(s)")
    except Exception as e:
        logger.error(f"Failed to sync commands: {e}")

@bot.event
async def on_command(ctx):
    logger.info(f'Command {ctx.command.name} was invoked by {ctx.author}')

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("У вас нет прав для выполнения этой команды!")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("Команда не найдена. Используйте !помощь для списка команд.")
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(f"⏰ Подождите {error.retry_after:.1f} секунд перед повторным использованием команды.")
    else:
        logger.error(f'Error occurred: {error}')
        await ctx.send("Произошла ошибка при выполнении команды.")

def main():
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        logger.error('No token found in .env file')
        return

    bot.run(token)

if __name__ == '__main__':
    main()